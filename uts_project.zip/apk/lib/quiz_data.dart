// quiz_data.dart
class Question {
  final String question;
  final List<String> options;
  final int correctAnswerIndex;
  final String? imageUrl; // URL gambar opsional

  Question({
    required this.question,
    required this.options,
    required this.correctAnswerIndex,
    this.imageUrl,
  });
}

class QuizData {
  final String title;
  final List<Question> questions;

  QuizData({
    required this.title,
    required this.questions,
  });
}

// Data kuis Manajemen Informatika
QuizData getMIQuizData() {
  return QuizData(
    title: 'Manajemen Informatika Quiz',
    questions: [
      Question(
        question: 'Apa kepanjangan dari "MI" dalam konteks jurusan kuliah Anda?',
        options: [
          'Manajemen Internet',
          'Manajemen Informatika',
          'Multimedia Interaktif',
          'Mobile Intelligence'
        ],
        correctAnswerIndex: 1,
      ),
      Question(
        question: 'Istilah "SKS" dalam perkuliahan memiliki arti:',
        options: [
          'Sistem Keamanan Siswa',
          'Satuan Kredit Semester',
          'Standar Kuliah Sementara',
          'Sistem Keren Studi'
        ],
        correctAnswerIndex: 1,
      ),
      Question(
        question: 'Program studi D4 Manajemen Informatika di UNESA berada di bawah fakultas apa?',
        options: [
          'Fakultas Teknik',
          'Fakultas Ilmu Sosial dan Hukum',
          'Fakultas Vokasi',
          'Fakultas Matematika dan Ilmu Pengetahuan Alam'
        ],
        correctAnswerIndex: 2,

      ),
      Question(
        question: 'Apa salah satu fokus utama D4 Manajemen Informatika UNESA?',
        options: [
          'Pengembangan aplikasi dan pengelolaan sistem informasi',
          'Desain interior',
          'Analisis kimia',
          'Pendidikan guru'
        ],
        correctAnswerIndex: 0,
      ),
      Question(
        question: 'Apa kepanjangan dari "D4" dalam konteks program studi Anda di UNESA?',
        options: [
          'Diploma 4',
          'Dasar 4 Tahun',
          'Digital 4',
          'Departemen 4'
        ],
        correctAnswerIndex: 0,
      ),
      Question(
        question: 'Siapa yang bertanggung jawab sebagai Koordinator Program Studi D4 Manajemen Informatika di UNESA?',
        options: [
          'Dekan Fakultas Vokasi',
          'Ketua Jurusan Teknik',
          'Bapak Dodik Arwin Dermawan, S.ST., S.T., M.T.',
          'Rektor UNESA'
        ],
        correctAnswerIndex: 2,

      ),
      Question(
        question: 'Fakultas Vokasi UNESA dipimpin oleh siapa?',
        options: [
          'Rektor',
          'Dekan',
          'Koordinator Program Studi',
          'Ketua HIMA'
        ],
        correctAnswerIndex: 1,
      ),
      Question(
        question: 'Fakultas Vokasi UNESA berlokasi di kampus mana?',
        options: [
          'Kampus Gunungsari',
          'Kampus Ketintang',
          'Kampus Lidah Wetan',
          'Kampus B Unesa'
        ],
        correctAnswerIndex: 1,

      ),
      Question(
        question: 'Berapa lama masa studi ideal untuk menyelesaikan D4 Manajemen Informatika di UNESA?',
        options: [
          '2 tahun',
          '3 tahun',
          '4 tahun',
          '5 tahun'
        ],
        correctAnswerIndex: 2,
      ),
      Question(
        question: 'Apa perbedaan utama antara D4 Manajemen Informatika dengan S1 di UNESA?',
        options: [
          'D4 lebih fokus pada teori akademik',
          'D4 memiliki durasi studi lebih lama',
          'D4 berorientasi pada keterampilan praktis dan siap kerja',
          'D4 tidak memerlukan skripsi'
        ],
        correctAnswerIndex: 2,

      ),
    ],
  );
}