// main.dart
import 'package:flutter/material.dart';
import 'quiz_data.dart';
import 'dart:async';

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatelessWidget {
  const QuizApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MI Quiz',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
        fontFamily: 'Poppins',
        visualDensity: VisualDensity.adaptivePlatformDensity,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.blue.shade800,
              Colors.blue.shade600,
              Colors.indigo.shade400,
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.quiz,
                size: 100,
                color: Colors.white,
              ),
              const SizedBox(height: 24),
              const Text(
                'MI QUIZ',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Manajemen Informatika Quiz',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white70,
                  fontWeight: FontWeight.w300,
                ),
              ),
              const SizedBox(height: 48),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => QuizScreen(
                        quizData: getMIQuizData(),
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue.shade800,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 16,
                  ),
                ),
                child: const Text(
                  'Mulai Kuis',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuizScreen extends StatefulWidget {
  final QuizData quizData;

  const QuizScreen({
    Key? key,
    required this.quizData,
  }) : super(key: key);

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> with SingleTickerProviderStateMixin {
  int _currentQuestionIndex = 0;
  int _score = 0;
  bool _isQuizFinished = false;
  int? _selectedOption;
  bool _hasAnswered = false;
  late AnimationController _animationController;
  late Animation<double> _animation;

  // Timer variables
  late Timer _timer;
  int _remainingSeconds = 60;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();

    // Start the timer for the first question
    _startTimer();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _timer.cancel();
    super.dispose();
  }

  void _startTimer() {
    _remainingSeconds = 60;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
        } else {
          // Time's up, automatically move to next question
          _timer.cancel();
          // If no option is selected, treat it as a wrong answer
          if (!_hasAnswered) {
            _checkAnswer(-1); // Pass an invalid index to mark as wrong
          }
        }
      });
    });
  }

  void _checkAnswer(int selectedOptionIndex) {
    if (_hasAnswered) return;

    // Cancel the current timer
    _timer.cancel();

    setState(() {
      _hasAnswered = true;
      _selectedOption = selectedOptionIndex;
    });

    final correctAnswerIndex = widget.quizData.questions[_currentQuestionIndex].correctAnswerIndex;

    if (selectedOptionIndex == correctAnswerIndex) {
      setState(() {
        _score++;
      });
    }

    // Delay before moving to next question
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!mounted) return;

      if (_currentQuestionIndex < widget.quizData.questions.length - 1) {
        _animationController.reverse().then((_) {
          setState(() {
            _currentQuestionIndex++;
            _hasAnswered = false;
            _selectedOption = null;
          });
          _animationController.forward();
          // Start a new timer for the next question
          _startTimer();
        });
      } else {
        setState(() {
          _isQuizFinished = true;
        });
      }
    });
  }

  void _resetQuiz() {
    // Cancel any existing timer
    _timer.cancel();

    _animationController.reverse().then((_) {
      setState(() {
        _currentQuestionIndex = 0;
        _score = 0;
        _isQuizFinished = false;
        _hasAnswered = false;
        _selectedOption = null;
      });
      _animationController.forward();
      // Start the timer for the first question
      _startTimer();
    });
  }

  @override
  Widget build(BuildContext context) {
    final accentColor = Colors.blue.shade700;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
        ),
        child: SafeArea(
          child: _isQuizFinished
              ? _buildResultScreen(accentColor)
              : _buildQuizScreen(accentColor),
        ),
      ),
    );
  }

  Widget _buildQuizScreen(Color accentColor) {
    final currentQuestion = widget.quizData.questions[_currentQuestionIndex];

    return FadeTransition(
      opacity: _animation,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back, color: accentColor),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  'MI Quiz',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
                // Timer display
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _remainingSeconds <= 10 ? Colors.red.shade100 : Colors.blue.shade100,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.timer,
                        size: 18,
                        color: _remainingSeconds <= 10 ? Colors.red : accentColor,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '$_remainingSeconds',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _remainingSeconds <= 10 ? Colors.red : accentColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Progress indicator
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pertanyaan ${_currentQuestionIndex + 1}/${widget.quizData.questions.length}',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: (_currentQuestionIndex + 1) / widget.quizData.questions.length,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation<Color>(accentColor),
                    borderRadius: BorderRadius.circular(10),
                    minHeight: 10,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Question
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Container(
                padding: const EdgeInsets.all(24.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      accentColor,
                      Colors.blue.shade500,
                    ],
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      currentQuestion.question,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    if (currentQuestion.imageUrl != null) ...[
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          currentQuestion.imageUrl!,
                          height: 150,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                                height: 150,
                                color: Colors.grey.shade200,
                                child: const Icon(Icons.image_not_supported),
                              ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Options
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: _buildOptions(accentColor),
                ),
              ),
            ),

            // Timer and score indicator
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Circular timer indicator
                  _remainingSeconds <= 10
                      ? _buildPulsingTimer(accentColor)
                      : _buildNormalTimer(accentColor),
                  const SizedBox(width: 24),
                  // Score
                  Column(
                    children: [
                      Text(
                        'Skor',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade700,
                        ),
                      ),
                      Text(
                        '$_score',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: accentColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNormalTimer(Color accentColor) {
    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          width: 60,
          height: 60,
          child: CircularProgressIndicator(
            value: _remainingSeconds / 60,
            backgroundColor: Colors.grey.shade200,
            valueColor: AlwaysStoppedAnimation<Color>(accentColor),
            strokeWidth: 8,
          ),
        ),
        Text(
          '$_remainingSeconds',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: accentColor,
          ),
        ),
      ],
    );
  }

  Widget _buildPulsingTimer(Color accentColor) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.9, end: 1.1),
      duration: const Duration(milliseconds: 500),
      builder: (context, value, child) {
        return Transform.scale(
          scale: value,
          child: Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 60,
                height: 60,
                child: CircularProgressIndicator(
                  value: _remainingSeconds / 60,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                  strokeWidth: 8,
                ),
              ),
              Text(
                '$_remainingSeconds',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ],
          ),
        );
      },
      onEnd: () {
        if (_remainingSeconds <= 10 && !_hasAnswered) {
          setState(() {});  // Trigger rebuild to restart animation
        }
      },
    );
  }

  List<Widget> _buildOptions(Color accentColor) {
    final currentQuestion = widget.quizData.questions[_currentQuestionIndex];
    final options = currentQuestion.options;
    final correctAnswerIndex = currentQuestion.correctAnswerIndex;

    return options.asMap().entries.map((entry) {
      final index = entry.key;
      final option = entry.value;

      // Determine option color based on selection and correctness
      Color backgroundColor;
      Color textColor;
      IconData? trailingIcon;

      if (_hasAnswered) {
        if (index == correctAnswerIndex) {
          backgroundColor = Colors.green.shade100;
          textColor = Colors.green.shade800;
          trailingIcon = Icons.check_circle;
        } else if (index == _selectedOption) {
          backgroundColor = Colors.red.shade100;
          textColor = Colors.red.shade800;
          trailingIcon = Icons.cancel;
        } else {
          backgroundColor = Colors.white;
          textColor = Colors.grey.shade800;
          trailingIcon = null;
        }
      } else {
        backgroundColor = Colors.white;
        textColor = Colors.grey.shade800;
        trailingIcon = null;
      }

      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: InkWell(
          onTap: _hasAnswered ? null : () => _checkAnswer(index),
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: const Offset(0, 2),
                ),
              ],
              border: Border.all(
                color: _selectedOption == index && !_hasAnswered
                    ? accentColor
                    : Colors.grey.shade200,
                width: 2,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: _hasAnswered && (index == correctAnswerIndex || index == _selectedOption)
                        ? (index == correctAnswerIndex ? Colors.green : Colors.red)
                        : accentColor.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      String.fromCharCode(65 + index), // A, B, C, D...
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _hasAnswered && (index == correctAnswerIndex || index == _selectedOption)
                            ? Colors.white
                            : accentColor,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    option,
                    style: TextStyle(
                      fontSize: 16,
                      color: textColor,
                    ),
                  ),
                ),
                if (trailingIcon != null)
                  Icon(
                    trailingIcon,
                    color: index == correctAnswerIndex ? Colors.green : Colors.red,
                  ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  Widget _buildResultScreen(Color accentColor) {
    final percentage = (_score / widget.quizData.questions.length) * 100;
    String message;
    IconData iconData;

    if (percentage >= 80) {
      message = 'Luar Biasa!';
      iconData = Icons.emoji_events;
    } else if (percentage >= 60) {
      message = 'Bagus!';
      iconData = Icons.thumb_up;
    } else {
      message = 'Coba Lagi!';
      iconData = Icons.refresh;
    }

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.blue.shade500,
            Colors.blue.shade700,
          ],
        ),
      ),
      child: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  message,
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
                const SizedBox(height: 16),
                Icon(
                  iconData,
                  size: 80,
                  color: accentColor,
                ),
                const SizedBox(height: 24),
                Text(
                  'Skor Anda:',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '$_score dari ${widget.quizData.questions.length}',
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
                Text(
                  '(${percentage.toStringAsFixed(0)}%)',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
                const SizedBox(height: 32),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.refresh),
                      label: const Text('Mulai Lagi'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      onPressed: _resetQuiz,
                    ),
                    const SizedBox(width: 16),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.home),
                      label: const Text('Menu Utama'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: accentColor,
                        side: BorderSide(color: accentColor),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      onPressed: () {
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}